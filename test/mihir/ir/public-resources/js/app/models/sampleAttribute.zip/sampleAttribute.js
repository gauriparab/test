/*global define:false*/
define(['jquery', 'underscore', 'models/baseModel', 'views/common/auditReasonView'], function($, _, BaseModel, AuditReasonView) {

    "use strict";

    var SampleAttribute = BaseModel.extend({        
        urlRoot: '/ir/secure/api/attributes/',
	
	methodUrl: {
            'create': '/ir/secure/api/attributes/addAttribute',
            'update': '/ir/secure/api/attributes/editAttribute'
        },

        /*validate : function() {
            if(this._validateString(this.get("attributeName"))){
                return "Please enter Attribute Name";
            }
        },

        _validateString : function(string) {
            return _.isUndefined(string) || _.isEmpty(string.trim());
        },*/

        sync: function(method, model, options) {
            if (model.methodUrl && model.methodUrl[method.toLowerCase()]) {
                options = options || {};
                options.url = model.methodUrl[method.toLowerCase()];
            }
            if(method === 'create' || method ==='update'){
		    	AuditReasonView.open(function() {
			  		model.set("reason", document.getElementById("reason").value);
			  	    Backbone.sync(method, model, options);
		  		});
		    } else{
		    	Backbone.sync(method, model, options);
		    }
        }        
    });

    return SampleAttribute;
});
