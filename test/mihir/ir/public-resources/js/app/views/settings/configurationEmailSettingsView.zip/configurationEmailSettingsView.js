/* global define:false*/
define([
        'models/settings/emailSettings',
        'models/settings/sendTestEmail',
        'views/common/bannersView',
        'views/ParentView',
        'views/common/baseModalView',
        'views/common/auditTrailView',
        'hb!templates/settings/configuration-email-settings-view.html'
        ],

		function(
				EmailSettings,
				SendTestEmail,
				BannersView,
				ParentView,
				BaseModalView,
				AuditTrailView,
				template) {

			'use strict';

			var ConfigurationNetworkSettingsView = ParentView.extend({

				_template : template,
				
				_settings:{},
				
				initialize : function(options) {
					var that = this;
					this.getEmailSettingsModel = new EmailSettings({requestType:'get'});
					this.setEmailSettingsModel = new EmailSettings({requestType:'set'});
					
					this.sendTestEmailModel = new SendTestEmail();
					
					this.getEmailSettingsModel.fetch({
						success:function(){
							that._settings = that.getEmailSettingsModel.toJSON();
							that.render();
						},
						error:function(){
							
						}
					});
				},
				
				events: {
					'click #update': '_saveSettings',
					'click #send-test': 'sendTestEmail',
					'click #reset': '_reset'	
				},

				delegateEvents : function() {
					Backbone.View.prototype.delegateEvents.apply(this, arguments);
				},

				undelegateEvents : function() {
					Backbone.View.prototype.undelegateEvents.apply(this, arguments);
				},

				render : function() {
					this.$el.html(this._template({settings:this._settings}));
				},

				_saveSettings:function(){
					
					this.setEmailSettingsModel.unset('requestType');
					
					var tls = $('#tls').is(':checked');
					var smtp = $('#smtp').val();
					var port = $('#port').val();
					var username = $('#email-username').val();
					var password = $('#email-password').val();
					var sender = $('#sender').val();
					
					this.setEmailSettingsModel.set('smtpServerURL',smtp);
					this.setEmailSettingsModel.set('port',port);
					this.setEmailSettingsModel.set('userName',username);
					this.setEmailSettingsModel.set('password',password);
					this.setEmailSettingsModel.set('senderAddress',sender);
					this.setEmailSettingsModel.set('useTLS',tls);
					
					this.setEmailSettingsModel.save(null,{
						success:function(){
							new BannersView({
								id : 'success-banner',
								container : $('.main-content #email-messages'),
								style : 'success',
								static : false,
								title : 'Email Settings Updated Successfully'
							}).render();
						},
						error:function(req,res){
							var res = JSON.parse(res.responseText);
							var message = res.rdxerrors.rdxObject[0].message;
							new BannersView({
								container : $('.main-content #email-messages'),
								style : 'error',
								static : false,
								title : message
							}).render();
						}
					});
					
				},
				
				sendTestEmail:function(){
					var tls = $('#tls').is(':checked');
					var smtp = $('#smtp').val();
					var port = $('#port').val();
					var username = $('#email-username').val();
					var password = $('#email-password').val();
					var sender = $('#sender').val();
					
					this.sendTestEmailModel.set('smtpServerURL',smtp);
					this.sendTestEmailModel.set('port',port);
					this.sendTestEmailModel.set('userName',username);
					this.sendTestEmailModel.set('password',password);
					this.sendTestEmailModel.set('senderAddress',sender);
					this.sendTestEmailModel.set('useTLS',tls);
					this.sendTestEmailModel.fetch({
						success:function(req,res){
							new BannersView({
								id : 'success-banner',
								container : $('.main-content #email-messages'),
								style : 'success',
								static : false,
								title : 'Test Email Sent Successfully.'
							}).render();
						},
						error:function(req,res){
							var res = JSON.parse(res.responseText);
							var message = res.rdxerrors.rdxObject[0].message;
							new BannersView({
								container : $('.main-content #email-messages'),
								style : 'error',
								static : false,
								title : message
							}).render();
						}
					});
				},
				
				_reset: function() {
					this.render();
				}
				
			});
			return ConfigurationNetworkSettingsView;
		});
